import { Routes } from '@angular/router';
import { ExtractionViewComponent } from './views/extraction/extraction-view.component';
import { ComparisonViewComponent } from './views/comparison/comparison-view.component';
import { WebSocketDemoComponent } from './views/websocket-demo/websocket-demo.component';

export const routes: Routes = [
  { path: '', redirectTo: '/extract', pathMatch: 'full' },
  { path: 'extract', component: ExtractionViewComponent },
  { path: 'compare', component: ComparisonViewComponent },
  { path: 'websocket', component: WebSocketDemoComponent },
  { path: '**', redirectTo: '/extract' }
];

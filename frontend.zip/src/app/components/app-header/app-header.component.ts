import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app-header.component.html',
  styleUrl: './app-header.component.css'
})
export class AppHeaderComponent {
  title = 'Contract Analysis Dashboard';
  subtitle = 'Extract, analyze, and compare healthcare reimbursement rules with AI precision';
  badge = 'AI-Powered • Secure • Compliant';
}

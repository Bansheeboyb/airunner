import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface NavItem {
  id: string;
  path: string;
  label: string;
  icon: string;
}

@Component({
  selector: 'app-left-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './left-sidebar.component.html',
  styleUrl: './left-sidebar.component.css'
})
export class LeftSidebarComponent {
  isCollapsed = false;

  navItems: NavItem[] = [
    {
      id: 'extract',
      path: '/extract',
      label: 'Extract Rules',
      icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M16 13H8 M16 17H8'
    },
    {
      id: 'compare',
      path: '/compare',
      label: 'Compare Contracts',
      icon: 'M12 2v20 M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6'
    },
    {
      id: 'websocket',
      path: '/websocket',
      label: 'WebSocket Demo',
      icon: 'M5 12h14M12 5l7 7-7 7'
    }
  ];

  toggleSidebar(): void {
    this.isCollapsed = !this.isCollapsed;
  }
}

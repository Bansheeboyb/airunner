import { Injectable, OnDestroy, signal, computed } from '@angular/core';
import { Observable, Subject, timer } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

export interface WebSocketMessage<T = unknown> {
  type: string;
  payload: T;
  timestamp: Date;
  id: string;
}

export interface WebSocketConfig {
  url: string;
  reconnectInterval?: number;
  maxReconnectAttempts?: number;
}

export type ConnectionStatus = 'connecting' | 'connected' | 'disconnected' | 'reconnecting' | 'error';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService implements OnDestroy {
  private socket: WebSocket | null = null;
  private config: WebSocketConfig | null = null;
  private reconnectAttempts = 0;
  private destroy$ = new Subject<void>();
  private manualClose = false;

  // Signals for reactive state
  private readonly _status = signal<ConnectionStatus>('disconnected');
  private readonly _lastError = signal<Error | null>(null);

  // Public signals (readonly)
  public readonly status = this._status.asReadonly();
  public readonly lastError = this._lastError.asReadonly();
  public readonly isConnected = computed(() => this._status() === 'connected');

  // RxJS subjects for message streams
  private messagesSubject = new Subject<WebSocketMessage>();
  private errorSubject = new Subject<Error>();

  // Public observables for streams
  public messages$ = this.messagesSubject.asObservable();
  public errors$ = this.errorSubject.asObservable();

  /**
   * Connect to a WebSocket server
   */
  connect(config: WebSocketConfig): void {
    this.config = {
      reconnectInterval: 3000,
      maxReconnectAttempts: 10,
      ...config
    };

    this.manualClose = false;
    this.establishConnection();
  }

  /**
   * Disconnect from the WebSocket server
   */
  disconnect(): void {
    this.manualClose = true;
    this.closeConnection();
    this._status.set('disconnected');
  }

  /**
   * Send a message through the WebSocket
   */
  send<T>(type: string, payload: T): boolean {
    if (this.socket?.readyState === WebSocket.OPEN) {
      const message: WebSocketMessage<T> = {
        type,
        payload,
        timestamp: new Date(),
        id: this.generateId()
      };
      this.socket.send(JSON.stringify(message));
      return true;
    }
    console.warn('WebSocket is not connected. Message not sent.');
    return false;
  }

  /**
   * Send raw data through the WebSocket
   */
  sendRaw(data: string | ArrayBuffer | Blob): boolean {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(data);
      return true;
    }
    console.warn('WebSocket is not connected. Message not sent.');
    return false;
  }

  /**
   * Filter messages by type
   */
  onMessage<T>(type: string): Observable<WebSocketMessage<T>> {
    return this.messages$.pipe(
      filter((msg): msg is WebSocketMessage<T> => msg.type === type)
    );
  }

  /**
   * Get current status value
   */
  get currentStatus(): ConnectionStatus {
    return this._status();
  }

  private establishConnection(): void {
    if (!this.config) return;

    console.log('[WebSocket] Attempting connection to', this.config.url);
    this._status.set('connecting');

    try {
      this.socket = new WebSocket(this.config.url);
      console.log('[WebSocket] Socket created, readyState:', this.socket.readyState);

      this.socket.onopen = () => {
        console.log('[WebSocket] onopen fired, readyState:', this.socket?.readyState);
        console.log('[WebSocket] Connected to', this.config?.url);
        this.reconnectAttempts = 0;
        this._status.set('connected');
      };

      this.socket.onmessage = (event: MessageEvent) => {
        this.handleMessage(event);
      };

      this.socket.onerror = (event: Event) => {
        console.log('[WebSocket] onerror fired');
        console.error('[WebSocket] Error:', event);
        const error = new Error('WebSocket error occurred');
        this._lastError.set(error);
        this.errorSubject.next(error);
        this._status.set('error');
      };

      this.socket.onclose = (event: CloseEvent) => {
        console.log('[WebSocket] onclose fired, code:', event.code, 'reason:', event.reason, 'wasClean:', event.wasClean);
        console.log('[WebSocket] Connection closed:', event.code, event.reason);

        if (!this.manualClose) {
          this.attemptReconnect();
        }
      };

    } catch (error) {
      console.error('[WebSocket] Failed to create connection:', error);
      this._lastError.set(error as Error);
      this.errorSubject.next(error as Error);
      this._status.set('error');
    }
  }

  private handleMessage(event: MessageEvent): void {
    try {
      // Try to parse as JSON
      const data = JSON.parse(event.data);

      const message: WebSocketMessage = {
        type: data.type || 'unknown',
        payload: data.payload ?? data,
        timestamp: data.timestamp ? new Date(data.timestamp) : new Date(),
        id: data.id || this.generateId()
      };

      this.messagesSubject.next(message);
    } catch {
      // If not JSON, wrap raw data
      const message: WebSocketMessage<string> = {
        type: 'raw',
        payload: event.data,
        timestamp: new Date(),
        id: this.generateId()
      };

      this.messagesSubject.next(message);
    }
  }

  private attemptReconnect(): void {
    if (!this.config) return;

    const { maxReconnectAttempts, reconnectInterval } = this.config;

    if (this.reconnectAttempts >= (maxReconnectAttempts || 10)) {
      console.error('[WebSocket] Max reconnection attempts reached');
      this._status.set('error');
      return;
    }

    this.reconnectAttempts++;
    this._status.set('reconnecting');

    console.log(`[WebSocket] Reconnecting... Attempt ${this.reconnectAttempts}/${maxReconnectAttempts}`);

    timer(reconnectInterval || 3000)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        if (!this.manualClose) {
          this.establishConnection();
        }
      });
  }

  private closeConnection(): void {
    if (this.socket) {
      this.socket.close(1000, 'Client disconnecting');
      this.socket = null;
    }
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.disconnect();
  }
}

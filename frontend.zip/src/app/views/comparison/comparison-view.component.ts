import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-comparison-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './comparison-view.component.html',
  styleUrl: './comparison-view.component.css'
})
export class ComparisonViewComponent {
  contract1: File | null = null;
  contract2: File | null = null;

  onContract1Selected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.contract1 = input.files[0];
    }
  }

  onContract2Selected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.contract2 = input.files[0];
    }
  }

  startComparison(): void {
    // Placeholder - will be implemented later
    console.log('Starting comparison...');
  }
}

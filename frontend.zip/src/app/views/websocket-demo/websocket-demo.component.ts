import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { WebSocketService, WebSocketMessage } from '../../services/websocket.service';

interface EventLogEntry {
  id: string;
  type: string;
  payload: unknown;
  timestamp: Date;
  direction: 'incoming' | 'outgoing';
}

@Component({
  selector: 'app-websocket-demo',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './websocket-demo.component.html',
  styleUrl: './websocket-demo.component.css'
})
export class WebSocketDemoComponent implements OnInit, OnDestroy {
  private readonly wsService = inject(WebSocketService);
  private destroy$ = new Subject<void>();

  // Connection settings
  wsUrl = 'ws://localhost:8080';

  // Use signal from service directly
  readonly connectionStatus = this.wsService.status;
  readonly isConnected = this.wsService.isConnected;

  // Message sending
  messageType = 'test';
  messagePayload = '{"message": "Hello WebSocket!"}';

  // Event log as signal
  private readonly _eventLog = signal<EventLogEntry[]>([]);
  readonly eventLog = this._eventLog.asReadonly();
  readonly maxLogEntries = 100;

  // Stats as signals
  private readonly _messagesReceived = signal(0);
  private readonly _messagesSent = signal(0);
  readonly messagesReceived = this._messagesReceived.asReadonly();
  readonly messagesSent = this._messagesSent.asReadonly();

  // Computed for status class
  readonly statusClass = computed(() => {
    switch (this.connectionStatus()) {
      case 'connected': return 'status-connected';
      case 'connecting':
      case 'reconnecting': return 'status-connecting';
      case 'error': return 'status-error';
      default: return 'status-disconnected';
    }
  });

  ngOnInit(): void {
    // Subscribe to all incoming messages
    this.wsService.messages$
      .pipe(takeUntil(this.destroy$))
      .subscribe(message => {
        this.handleIncomingMessage(message);
      });

    // Subscribe to errors
    this.wsService.errors$
      .pipe(takeUntil(this.destroy$))
      .subscribe(error => {
        this.addSystemMessage(`Error: ${error.message}`, 'error');
      });
  }

  connect(): void {
    this.wsService.connect({
      url: this.wsUrl,
      reconnectInterval: 3000,
      maxReconnectAttempts: 5
    });
  }

  disconnect(): void {
    this.wsService.disconnect();
  }

  sendMessage(): void {
    try {
      const payload = JSON.parse(this.messagePayload);
      const success = this.wsService.send(this.messageType, payload);

      if (success) {
        this._messagesSent.update(v => v + 1);
        this.addLogEntry({
          id: `sent-${Date.now()}`,
          type: this.messageType,
          payload: payload,
          timestamp: new Date(),
          direction: 'outgoing'
        });
      }
    } catch (e) {
      // If not valid JSON, send as string
      const success = this.wsService.send(this.messageType, this.messagePayload);

      if (success) {
        this._messagesSent.update(v => v + 1);
        this.addLogEntry({
          id: `sent-${Date.now()}`,
          type: this.messageType,
          payload: this.messagePayload,
          timestamp: new Date(),
          direction: 'outgoing'
        });
      }
    }
  }

  clearLog(): void {
    this._eventLog.set([]);
    this._messagesReceived.set(0);
    this._messagesSent.set(0);
  }

  private handleIncomingMessage(message: WebSocketMessage): void {
    this._messagesReceived.update(v => v + 1);
    this.addLogEntry({
      id: message.id,
      type: message.type,
      payload: message.payload,
      timestamp: message.timestamp,
      direction: 'incoming'
    });
  }

  private addLogEntry(entry: EventLogEntry): void {
    this._eventLog.update(log => {
      const newLog = [entry, ...log];
      return newLog.slice(0, this.maxLogEntries);
    });
  }

  private addSystemMessage(message: string, type: string = 'system'): void {
    this.addLogEntry({
      id: `system-${Date.now()}`,
      type: type,
      payload: message,
      timestamp: new Date(),
      direction: 'incoming'
    });
  }

  formatPayload(payload: unknown): string {
    if (typeof payload === 'string') {
      return payload;
    }
    return JSON.stringify(payload, null, 2);
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
